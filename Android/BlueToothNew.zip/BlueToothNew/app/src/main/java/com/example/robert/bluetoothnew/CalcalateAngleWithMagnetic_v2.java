package com.example.robert.bluetoothnew;

import com.google.android.gms.maps.model.LatLng;

/**
 * Created by robert on 2017/11/11.
 */

public class CalcalateAngleWithMagnetic_v2 {
    LatLng lastPosition,currentPosition,directionPosition;
    public CalcalateAngleWithMagnetic_v2(){}
    public void setLastPosition(LatLng lastPosition){
        this.lastPosition = lastPosition;
    }
    public void setCurrentPosition(LatLng currentPosition){
        this.currentPosition = currentPosition;
    }
    public void setDirectionPosition(LatLng directionPosition){
        this.directionPosition = directionPosition;
    }
    public void expectedAction(){
        LatLng tempVector = new LatLng(directionPosition.latitude - currentPosition.latitude , directionPosition.longitude - currentPosition.longitude);
        double constant1 = (tempVector.latitude * lastPosition.latitude) + (tempVector.longitude * lastPosition.longitude);
        double constant2 = (tempVector.latitude * currentPosition.latitude) - (tempVector.longitude * currentPosition.longitude);

    }
}
